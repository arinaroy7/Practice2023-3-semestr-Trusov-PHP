import React from 'react';

function LoginForm() {
    return (
        <div>
            {/*Форма для ввода логина и пароля */}
        </div>
    );
}

export default LoginForm; 